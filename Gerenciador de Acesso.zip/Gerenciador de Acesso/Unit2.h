//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <DBCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmHistorico : public TForm
{
__published:	// IDE-managed Components
        TDBGrid *DBGrid1;
        TDBNavigator *DBNavigator1;
private:	// User declarations
public:		// User declarations
        __fastcall TfrmHistorico(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmHistorico *frmHistorico;
//---------------------------------------------------------------------------
#endif
