//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmHistorico *frmHistorico;
//---------------------------------------------------------------------------
__fastcall TfrmHistorico::TfrmHistorico(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------




