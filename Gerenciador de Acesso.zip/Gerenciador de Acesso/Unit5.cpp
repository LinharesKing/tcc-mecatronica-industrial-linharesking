//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit5.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmLogin *frmLogin;
//---------------------------------------------------------------------------
__fastcall TfrmLogin::TfrmLogin(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmLogin::btnAcessarClick(TObject *Sender)
{

        if(EdtUser->Text != "Master_007" || EdtSenha->Text != "mnasdpoi1qaz")
        {
              Application->MessageBox("Login ou senha inv�lidos","Error", MB_OK | MB_ICONWARNING);
        }else{
                Hide(); //oculta a tela de login
                Form1 = new TForm1(Application);
                Form1->Show(); //abre a tela inicial
        }
}
//---------------------------------------------------------------------------

void __fastcall TfrmLogin::btnSairClick(TObject *Sender)
{
        Application->Terminate();
}
//---------------------------------------------------------------------------


