//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmCadUser *frmCadUser;
//---------------------------------------------------------------------------
__fastcall TfrmCadUser::TfrmCadUser(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmCadUser::btnCadastraClick(TObject *Sender)
{
        AnsiString myQuery, nome;
        String resultado, valor;

        if(edtNome->Text == "")
        {
                Application->MessageBox("Por favor preencha o campo Nome","Aten��o !", MB_OK | MB_ICONWARNING);
        }else
        {

                if(Form1->Status == "Aproxime o cart�o da Fechadura Eletr�nica!")
                {
                        Application->MessageBox("Aproxime o cart�o da Fechadura Eletr�nica!","Aten��o !", MB_OK | MB_ICONWARNING);
                }else
                {

                        valor = lblTag->Caption;

                        myQuery =  "select TAG from cadastro where TAG = '"+valor+"'";

                        Form1->queryCadastro->Close();
                        Form1->queryCadastro->SQL->Clear();
                        Form1->queryCadastro->SQL->Add(myQuery);
                        Form1->queryCadastro->Open();

                        resultado = Form1->queryCadastro->FieldByName("TAG")->AsString;

                        if((resultado == valor)&&(valor != ""))
                        {
                                Application->MessageBox("TAG j� cadastrada, Use outro cart�o !","Aten��o !", MB_OK | MB_ICONWARNING);
                        }else{

                                if((valor == ""))
                                {
                                        Application->MessageBox("Aproxime o cart�o da Fechadura Eletr�nica!","Aten��o !", MB_OK | MB_ICONWARNING);
                                }else
                                {
                                        nome = edtNome->Text;
                                        myQuery =  "INSERT INTO cadastro( ID, NOME, TAG) VALUES ( NULL, '"+nome+"', '"+lblTag->Caption+"')";

                                        Form1->queryCadastro->Close();
                                        Form1->queryCadastro->SQL->Clear();
                                        Form1->queryCadastro->SQL->Add(myQuery);
                                        Form1->queryCadastro->ExecSQL();
                                        Application->MessageBox("Usu�rio Cadastrado Com Sucesso !","Information", MB_OK | MB_ICONINFORMATION);
                                        frmCadUser->Close();
                                }
                        }

                        lblTag->Caption = "";

                }

        }        
}
//---------------------------------------------------------------------------
void __fastcall TfrmCadUser::Timer1Timer(TObject *Sender)
{
        if(Form1->Status == "Tag detectada")
        {
             Label3->Visible=true;
             lblStatus->Visible=false;
        }else{
                Label3->Visible=false;
                lblStatus->Visible=true;
        }
        if(Form1->TAG.Length()== 11){
                lblTag->Caption = Form1->TAG;
        }

}
//---------------------------------------------------------------------------
void __fastcall TfrmCadUser::FormCreate(TObject *Sender)
{
        Form1->TAG = "";
        Form1->Status = "Aproxime o cart�o da Fechadura Eletr�nica!";
        KeyPreview = True;//garante que o manipulador de eventos OnKeyDown do Form � chamado
}
//---------------------------------------------------------------------------


void __fastcall TfrmCadUser::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if (Key == VK_SPACE)// se pressionar ESPACE
        {
                btnCadastra->Click();
        }
}
//---------------------------------------------------------------------------

