//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmCadUser : public TForm
{
__published:	// IDE-managed Components
        TEdit *edtNome;
        TBitBtn *btnCadastra;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *lblStatus;
        TTimer *Timer1;
        TLabel *lblTag;
        TLabel *Label3;
        void __fastcall btnCadastraClick(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmCadUser(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmCadUser *frmCadUser;
//---------------------------------------------------------------------------
#endif
