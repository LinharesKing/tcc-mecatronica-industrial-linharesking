//---------------------------------------------------------------------------

#ifndef Unit4H
#define Unit4H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <DBCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmListUser : public TForm
{
__published:	// IDE-managed Components
        TDBGrid *DBGrid1;
        TDBNavigator *DBNavigator1;
private:	// User declarations
public:		// User declarations
        __fastcall TfrmListUser(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmListUser *frmListUser;
//---------------------------------------------------------------------------
#endif
