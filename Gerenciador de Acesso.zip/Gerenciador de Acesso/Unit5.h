//---------------------------------------------------------------------------

#ifndef Unit5H
#define Unit5H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include <Buttons.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TfrmLogin : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TBitBtn *btnAcessar;
        TMaskEdit *EdtSenha;
        TEdit *EdtUser;
        TLabel *Label1;
        TLabel *Label2;
        TBitBtn *btnSair;
        void __fastcall btnAcessarClick(TObject *Sender);
        void __fastcall btnSairClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmLogin(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmLogin *frmLogin;
//---------------------------------------------------------------------------
#endif
