//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
#include "Unit5.h"
#include "Unit6.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CPort"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnConectClick(TObject *Sender)
{

        if(ComPortSerial->Connected){ //Caso j� houver alguma comunica�o aberta, esta ser� fechada

                ComPortSerial->Close();
        }

        ComPortSerial->ShowSetupDialog(); //Abre a janela de configura��es  da comunica��o serial

        try
        {
                ComPortSerial->Open();
                if(ComPortSerial->Connected)

                {
                        Application->MessageBox("Conectado com sucesso","Information", MB_OK | MB_ICONINFORMATION);
                        btnConect->Visible = false;
                }else{

                        Application->MessageBox("Falha ao abrir conex�o","Error", MB_OK | MB_ICONWARNING);
                }

        }
        catch(Exception& E){

                Application->MessageBox("Erro ao abrir conex�o","Error", MB_OK | MB_ICONWARNING);
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnDisconectClick(TObject *Sender)
{       try
        {
                ComPortSerial->Close();
                btnConect->Visible = true;

        }
        catch(Exception& E){

                Application->MessageBox("Erro ao fechar a conex�o","Error", MB_OK | MB_ICONWARNING);
                Form1->Close();
        }


}
//---------------------------------------------------------------------------


void __fastcall TForm1::ImgHistClick(TObject *Sender)
{
        myQuery =  "select *from historicodeacesso";

        queryHistorico->Close();
        queryHistorico->SQL->Clear();
        queryHistorico->SQL->Add(myQuery);
        queryHistorico->Open();

        frmHistorico = new TfrmHistorico(Application);
        frmHistorico->ShowModal(); //Abre a tela frmHistorico
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ImgCadUserClick(TObject *Sender)
{
        if(!ComPortSerial->Connected)
        {
                Application->MessageBox("Sem Conex�o com a Fechadura Eletr�nica","Error", MB_OK | MB_ICONWARNING);
        }else
        {

                frmCadUser = new TfrmCadUser(Application);
                frmCadUser->ShowModal(); //Abre a tela frmCadUser
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ComPortSerialRxChar(TObject *Sender, int Count)
{

        String resultado,nome;

        ComPortSerial->ReadStr(aux,Count);

        if(lblValor->Caption.Length()<11)
        {
             lblValor->Caption = lblValor->Caption + aux;

        }else{

        lblValor->Caption = aux;

        }

        if(lblValor->Caption.Length()== 11)
        {
                TAG = lblValor->Caption;
                Status = "Tag detectada";
                myQuery =  "select TAG from cadastro where TAG = '"+TAG+"'";

                queryCadastro->Close();
                queryCadastro->SQL->Clear();
                queryCadastro->SQL->Add(myQuery);
                queryCadastro->Open();

                resultado = queryCadastro->FieldByName("TAG")->AsString;

                if(resultado == TAG)
                {
                        ComPortSerial->WriteStr('S');
                        lblResposta->Caption =  "S";

                        myQuery =  "select NOME from cadastro where TAG = '"+TAG+"'";

                        queryCadastro->Close();
                        queryCadastro->SQL->Clear();
                        queryCadastro->SQL->Add(myQuery);
                        queryCadastro->Open();

                        nome = queryCadastro->FieldByName("NOME")->AsString;

                        if(nome != "")
                        {


                                myQuery =  "insert into historicodeacesso (ID, DATAHORA, NOME) values (NULL, NOW(), '"+nome+"')";

                                queryHistorico->Close();
                                queryHistorico->SQL->Clear();
                                queryHistorico->SQL->Add(myQuery);
                                queryHistorico->ExecSQL();

                                myQuery =  "select *from historicodeacesso";

                                queryHistorico->Close();
                                queryHistorico->SQL->Clear();
                                queryHistorico->SQL->Add(myQuery);
                                queryHistorico->Open();

                                frmHistorico->DBGrid1->Refresh();

                                lblValor->Caption = "";
                        }
                }else{
                        ComPortSerial->WriteStr('N');
                        lblResposta->Caption =  "N";
                }

        }


        if(TAG == "")
        {
                Status = "Aproxime o cart�o da Fechadura Eletr�nica!";
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
        Status = "Aproxime o cart�o da Fechadura Eletr�nica!";
        ComPortSerial->LoadSettings (stIniFile, GetCurrentDir() + "\\configport.ini");
        KeyPreview = True;//garante que o manipulador de eventos OnKeyDown do Form � chamado
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ImgListClick(TObject *Sender)
{
        myQuery =  "select *from cadastro";

        queryCadastro->Close();
        queryCadastro->SQL->Clear();
        queryCadastro->SQL->Add(myQuery);
        queryCadastro->Open();


        frmListUser = new TfrmListUser(Application);
        frmListUser->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        if (Key == VK_F11)// se pressionar F11
        {
                ImgSobreClick(Sender);
        }

        if (Key == VK_F1)// se pressionar F1
        {
                btnConect->Click();
        }

        if (Key == VK_ESCAPE)// se pressionar o bot�o Esc
        {
                btnDisconect->Click();
        }

        if (Key == 0x43) //se pressionar o bot�o "C"
        {
                ImgCadUserClick(Sender);

        }

        if (Key == 0x48) //se pressionar o bot�o "H"
        {
                ImgHistClick(Sender);

        }

        if (Key == 0x4C) //se pressionar o bot�o "L"
        {
                ImgListClick(Sender);

        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
        Application->Terminate();//Ao fechar a tela inicial a aplica��o � encerrada        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ImgSobreClick(TObject *Sender)
{
        frmSobre = new TfrmSobre(Application);
        frmSobre->ShowModal();
}
//---------------------------------------------------------------------------

