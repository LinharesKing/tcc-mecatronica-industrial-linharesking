//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("Unit1.cpp", Form1);
USEFORM("Unit2.cpp", frmHistorico);
USEFORM("Unit3.cpp", frmCadUser);
USEFORM("Unit4.cpp", frmListUser);
USEFORM("Unit5.cpp", frmLogin);
USEFORM("Unit6.cpp", frmSobre);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TfrmLogin), &frmLogin);
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TfrmHistorico), &frmHistorico);
                 Application->CreateForm(__classid(TfrmCadUser), &frmCadUser);
                 Application->CreateForm(__classid(TfrmListUser), &frmListUser);
                 Application->CreateForm(__classid(TfrmSobre), &frmSobre);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
