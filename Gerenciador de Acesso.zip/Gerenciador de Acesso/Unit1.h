//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include "CPort.hpp"
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *btnDisconect;
        TBitBtn *btnConect;
        TComPort *ComPortSerial;
        TImage *ImgCadUser;
        TImage *ImgHist;
        TLabel *Label1;
        TLabel *Label2;
        TADOConnection *ADOConnection1;
        TADOQuery *queryHistorico;
        TDataSource *DataSourceHistorico;
        TDataSource *DataSourceCadastro;
        TADOQuery *queryCadastro;
        TLabel *lblValor;
        TImage *ImgList;
        TLabel *Label3;
        TImage *ImgSobre;
        TLabel *lblResposta;
        void __fastcall btnConectClick(TObject *Sender);
        void __fastcall btnDisconectClick(TObject *Sender);
        void __fastcall ImgHistClick(TObject *Sender);
        void __fastcall ImgCadUserClick(TObject *Sender);
        void __fastcall ComPortSerialRxChar(TObject *Sender, int Count);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ImgListClick(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall ImgSobreClick(TObject *Sender);
private:	// User declarations
public:
        AnsiString myQuery,aux,Status,TAG;
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
